from django.contrib import admin
from .models import BloodPressureMeasurement

admin.site.register(BloodPressureMeasurement)