from django.apps import AppConfig


class BloodPressureConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'blood_pressure'