from django.contrib import admin
from .models import Livros

# Register your models here.

admin.site.register(Livros)