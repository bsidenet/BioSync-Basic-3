from django.db import models
from datetime import date

# Create your models here.

class Medicoes(models.Model):
    id = models.AutoField(primary_key = True)
    nome = models.CharField(max_length = 100)
    data = models.DateField(default = date.today)
    hora = models.TimeField()
    pressao_siatolica = models.IntegerField()
    pressao_diastolica = models.IntegerField()
    frequencia_cardiaca = models.IntegerField()
    observacoes = models.TextField()
    class Meta:
        verbose_name = 'Medicao'

    def __str__(self):
        return self.nome
