from django.db import models

# Criar os modelos para Utentes

class Utentes(models.Model):
    id = models.AutoField(primary_key=True)
    nome = models.CharField(max_length=100)
    data_nascimento = models.DateField()
    morada = models.CharField(max_length=100)
    codigo_postal = models.CharField(max_length=8)
    localidade = models.CharField(max_length=50)
    contacto = models.IntegerField()
    email = models.EmailField()
    genero = models.CharField(max_length=1)
    observacoes = models.TextField()